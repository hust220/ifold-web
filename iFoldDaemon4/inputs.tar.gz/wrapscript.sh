#!/bin/sh
set -e
perl calcPfold.pl 1349-pdbFileName 1349-pdbDecoyFileName 10 0.8
