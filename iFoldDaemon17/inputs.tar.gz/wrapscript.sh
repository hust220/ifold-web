#!/bin/sh
set -e
perl runDMD.pl init.txt 1.2 1.0E-4 0.2 20000
